const kakaoJsKey = 'a70d6a6868de7c47c629a79acccf06e4';
const kakaoRestKey = '710e900c7c6ed0d469cf8d6f616d986a';
const roadAddrKey = 'U01TX0FVVEgyMDI0MDcyOTExMTcyNjExNDk3MDE=';

//도로명주소 api: U01TX0FVVEgyMDI0MDcyOTExMTcyNjExNDk3MDE=
