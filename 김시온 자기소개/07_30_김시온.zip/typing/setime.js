setTimeout(function(){
    console.log("Hello World");
}, 2000);

console.log("asdga");